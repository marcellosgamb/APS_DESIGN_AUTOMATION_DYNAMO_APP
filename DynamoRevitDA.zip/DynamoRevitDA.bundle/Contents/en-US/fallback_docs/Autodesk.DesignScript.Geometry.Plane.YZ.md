## In Depth
Plane YZ creates a plane in the world YZ directions. The normal of this plane is the world X-Axis. In the example file, we show Plane XY, Plane YZ, and Plane XZ. In the image, the YZ plane is highlighted.
___
## Example File

![YZ](./Autodesk.DesignScript.Geometry.Plane.YZ_img.jpg)

