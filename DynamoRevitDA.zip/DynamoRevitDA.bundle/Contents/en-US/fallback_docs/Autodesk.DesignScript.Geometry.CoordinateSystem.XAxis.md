## In Depth
XAxis will return a Vector that represents the WorldCoordinateSystem X axis. In the example below, the Vector returned is used to create a Line that follows the WCS X axis.
___
## Example File

![XAxis](./Autodesk.DesignScript.Geometry.CoordinateSystem.XAxis_img.jpg)

