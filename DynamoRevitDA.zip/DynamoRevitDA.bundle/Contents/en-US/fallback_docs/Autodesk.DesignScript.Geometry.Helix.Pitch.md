## In Depth
Pitch will return the linear distance along the axis direction that a helix spans in one complete turn (360 degrees). In the example below, we create a helix using Helix by Axis, then use Pitch to find the pitch of the helix.
___
## Example File

![Pitch](./Autodesk.DesignScript.Geometry.Helix.Pitch_img.jpg)

