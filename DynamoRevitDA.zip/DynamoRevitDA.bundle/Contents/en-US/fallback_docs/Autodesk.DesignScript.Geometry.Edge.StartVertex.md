## In Depth
StartVertex will return the Vertex at the start of an Edge. In the example below, a start Vertex is represented as a Point.
___
## Example File

![StartVertex](./Autodesk.DesignScript.Geometry.Edge.StartVertex_img.jpg)

