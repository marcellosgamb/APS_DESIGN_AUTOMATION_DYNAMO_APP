## In Depth
Bounding Box MinPoint returns the point that has the smallest X, Y and Z values. This example shows a Bounding Box MinPoint of a Sphere.
___
## Example File

![MinPoint](./Autodesk.DesignScript.Geometry.BoundingBox.MinPoint_img.jpg)

