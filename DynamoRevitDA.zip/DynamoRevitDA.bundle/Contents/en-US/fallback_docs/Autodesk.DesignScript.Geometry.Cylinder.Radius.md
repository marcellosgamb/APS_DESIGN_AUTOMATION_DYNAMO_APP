## In Depth
`Cylinder.Radius` returns the radius of a cylinder as a double. 

In the example below, adjusting the number slider will change the cylinder's radius.

___
## Example File

![Radius](./Autodesk.DesignScript.Geometry.Cylinder.Radius_img.jpg)

