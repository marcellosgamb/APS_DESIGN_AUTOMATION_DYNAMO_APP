## In Depth
PolyCurve.ByThickeningCurveNormal creates a PolyCurve by thickening a given curve along a plane specified by the input normal. For example, this node will create and offset boundary on each side of the input curve.
___
## Example File

![PolyCurve.ByThickeningCurveNormal](./Autodesk.DesignScript.Geometry.PolyCurve.ByThickeningCurveNormal_img.png)