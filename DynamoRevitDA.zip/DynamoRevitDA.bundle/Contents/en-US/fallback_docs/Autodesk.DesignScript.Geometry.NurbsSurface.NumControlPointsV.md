## In Depth
NumControlPointsV will count the control points in the V direction of a NurbsSurface and return an integer. In the example below, the NurbsSurface returns an integer of 12 for its V control points. The control points are returned as Points using NurbsSurface.ControlPoints.
___
## Example File

![NumControlPointsV](./Autodesk.DesignScript.Geometry.NurbsSurface.NumControlPointsV_img.jpg)

