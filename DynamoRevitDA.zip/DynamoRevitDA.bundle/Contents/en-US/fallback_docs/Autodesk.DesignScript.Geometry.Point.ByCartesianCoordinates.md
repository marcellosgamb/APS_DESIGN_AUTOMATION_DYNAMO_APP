## In Depth
Point By Cartesian Coordinates gives us the ability to set the X, Y and Z values of a point’s location. In this example, we are setting multiple Code Block Ranges controlled by sliders to drive the three-dimensional array of points.
___
## Example File

![ByCartesianCoordinates](./Autodesk.DesignScript.Geometry.Point.ByCartesianCoordinates_img.jpg)

