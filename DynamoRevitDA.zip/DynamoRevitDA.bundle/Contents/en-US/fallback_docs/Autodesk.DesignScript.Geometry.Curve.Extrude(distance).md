## In Depth
Extrudes a Curve in the normal direction, by the specified distance
___
## Example File

![Extrude (distance)](./Autodesk.DesignScript.Geometry.Curve.Extrude(distance)_img.jpg)

