## In Depth
Edges will return a List of Edges from an input geometry. In the example below, a Cuboid returns a List of 12 Edges.
___
## Example File

![Edges](./Autodesk.DesignScript.Geometry.Topology.Edges_img.jpg)

