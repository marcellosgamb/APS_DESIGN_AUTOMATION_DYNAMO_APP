## In Depth
ZAxis will return a Vector that represents the WorldCoordinateSystem Z axis. In the example below, the Vector returned is used to create a Line that follows the WCS Z axis.
___
## Example File

![ZAxis](./Autodesk.DesignScript.Geometry.CoordinateSystem.ZAxis_img.jpg)

