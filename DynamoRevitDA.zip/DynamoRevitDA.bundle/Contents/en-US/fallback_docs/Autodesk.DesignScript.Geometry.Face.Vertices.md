## In Depth
Vertices will return a List of Vertex locations for an input geometry. In the example below, the a Cuboid returns a list of 8 Vertex locations.
___
## Example File

![Vertices](./Autodesk.DesignScript.Geometry.Face.Vertices_img.jpg)

