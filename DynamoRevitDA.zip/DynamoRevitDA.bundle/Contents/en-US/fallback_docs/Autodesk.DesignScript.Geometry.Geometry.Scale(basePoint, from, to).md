## In Depth
Scale uniformly around a given point, using two pick points as scalars.
___
## Example File

![Scale (basePoint, from, to)](./Autodesk.DesignScript.Geometry.Geometry.Scale(basePoint,%20from,%20to)_img.jpg)

