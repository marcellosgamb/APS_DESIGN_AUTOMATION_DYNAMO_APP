## In Depth
ExportToSAT will export the specified geomety to the given SAT file path.
___
## Example File

![ExportToSAT](./Autodesk.DesignScript.Geometry.Geometry.ExportToSAT_img.jpg)

