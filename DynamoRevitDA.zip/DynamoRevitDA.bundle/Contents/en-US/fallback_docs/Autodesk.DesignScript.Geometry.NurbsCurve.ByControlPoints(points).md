## In Depth
Nurbs Curve By Control Points inputs a list of points to use as control points and outputs a Nurbs Curve. This example uses a Code Block to generate two lists corresponding to X and Y locations of a series of points. The points are used to draw the Nurbs Curve.
___
## Example File

![ByControlPoints (points)](./Autodesk.DesignScript.Geometry.NurbsCurve.ByControlPoints(points)_img.jpg)

