## In Depth
`PolySurface.Surfaces` returns the surfaces that make up a PolySurface. 

In the example below, `PolySurface.Surfaces` is used to return eight individual surfaces from an extruded hexagon.


___
## Example File

![PolySurface.Surfaces](./Autodesk.DesignScript.Geometry.PolySurface.Surfaces_img.jpg)