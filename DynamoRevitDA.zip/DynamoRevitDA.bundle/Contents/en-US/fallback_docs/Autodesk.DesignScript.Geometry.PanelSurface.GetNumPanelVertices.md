## In Depth
Returns the number of vertices for each panel in the list of panel indices.
___
## Example File

![GetNumPanelVertices](./Autodesk.DesignScript.Geometry.PanelSurface.GetNumPanelVertices_img.jpg)
