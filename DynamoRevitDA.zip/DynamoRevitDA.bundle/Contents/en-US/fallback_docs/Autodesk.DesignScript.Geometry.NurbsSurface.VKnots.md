## In Depth
VKnots will return the Surface Knots in the V direction of a NurbsSurface. In the example below, the VKnots of the NurbsSurface are returned as a list of doubles.
___
## Example File

![VKnots](./Autodesk.DesignScript.Geometry.NurbsSurface.VKnots_img.jpg)

