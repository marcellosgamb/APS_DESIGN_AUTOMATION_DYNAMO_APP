## In Depth
D will return the value of Index D. In the example below, the Index value of D is returned as 3 in a four-sided Mesh.
___
## Example File

![D](./Autodesk.DesignScript.Geometry.IndexGroup.D_img.jpg)

