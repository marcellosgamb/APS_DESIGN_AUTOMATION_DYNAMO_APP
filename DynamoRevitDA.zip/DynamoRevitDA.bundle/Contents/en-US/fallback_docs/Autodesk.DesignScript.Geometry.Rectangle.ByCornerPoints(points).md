## In Depth
The Rectangle By Corner Points node takes a list of four input points and creates a rectangle from them. The input points must reflect a rectangle form. In this example, two Number Sliders are used to create the Points By Coordinates at the rectangle’s vertices. A similar but distinct Rectangle ByCornerPoints node uses four separate inputs for eacher point rather than as a single list. Both nodes are shown in this example.
___
## Example File

![ByCornerPoints (points)](./Autodesk.DesignScript.Geometry.Rectangle.ByCornerPoints(points)_img.jpg)

