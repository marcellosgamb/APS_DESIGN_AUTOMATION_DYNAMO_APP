## In Depth
Surface.ByUnion will join all input surfaces together. It will return a polysurface if the input surfaces result in a multi-face surface.
___
## Example File

![Surface.ByUnion](./Autodesk.DesignScript.Geometry.Surface.ByUnion_img.png)