## In Depth
Remove vertices that do not lie on the input FACE.
___
## Example File

![PanelSurfaceBoundaryCondition.RemoveVertices](./Autodesk.DesignScript.Geometry.PanelSurfaceBoundaryCondition.RemoveVertices_img.jpg)
