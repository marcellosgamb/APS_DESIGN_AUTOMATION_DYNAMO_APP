## In Depth
Returns the points for each panel in the list of panel indices.
___
## Example File

![GetPanelPoints](./Autodesk.DesignScript.Geometry.PanelSurface.GetPanelPoints_img.jpg)
