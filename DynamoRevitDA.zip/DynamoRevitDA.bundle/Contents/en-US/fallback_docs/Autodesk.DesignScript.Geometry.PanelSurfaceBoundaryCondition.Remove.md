## In Depth
Do not allow panels to overlap the boundary.
___
## Example File

![PanelSurfaceBoundaryCondition.Remove](./Autodesk.DesignScript.Geometry.PanelSurfaceBoundaryCondition.Remove_img.jpg)
