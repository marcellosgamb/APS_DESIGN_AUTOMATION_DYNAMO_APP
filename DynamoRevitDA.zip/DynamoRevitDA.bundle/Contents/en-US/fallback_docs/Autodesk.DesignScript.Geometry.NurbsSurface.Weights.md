## In Depth
Weights will return the Weights of a NurbsSurface as doubles in a List of Lists. In the example below, a NurbsSurface returns a list of Weights with a value of 1.
___
## Example File

![Weights](./Autodesk.DesignScript.Geometry.NurbsSurface.Weights_img.jpg)

