## In Depth
Bounding Box ToCuboid creates a Cuboid geometry from a Bounding Box. In order to visualize the relationship of the input Sphere to the Cuboid in the example, we are extracting its edge curves.
___
## Example File

![ToCuboid](./Autodesk.DesignScript.Geometry.BoundingBox.ToCuboid_img.jpg)

