## In Depth
Geometry DoesIntersect tests two geometries for an intersection. If the objects intersect, the Node will return True. This example tests for an intersection of two Sphere geometries.
___
## Example File

![DoesIntersect](./Autodesk.DesignScript.Geometry.Geometry.DoesIntersect_img.jpg)

