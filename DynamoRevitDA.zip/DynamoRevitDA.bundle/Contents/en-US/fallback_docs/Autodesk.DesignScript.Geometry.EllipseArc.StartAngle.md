## In Depth
Start Angle finds the starting angle of the ellipse arc. This is measured in degrees counter-clockwise starting from the plane X-axis. In the example, we first create an Ellipse Arc by using the XY plane and a series of number sliders. We then use Start Angle to extract the angle of the beginning pont of the ellipse.
___
## Example File

![StartAngle](./Autodesk.DesignScript.Geometry.EllipseArc.StartAngle_img.jpg)

