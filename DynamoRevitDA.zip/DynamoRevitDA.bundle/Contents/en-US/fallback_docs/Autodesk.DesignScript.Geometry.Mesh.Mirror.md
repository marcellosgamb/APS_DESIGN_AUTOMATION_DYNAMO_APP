## In-Depth
`Mesh.Mirror` reflects a mesh across a defined plane. In this example, we are mirroring half of the vase across the Y-Axis.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Mirror_img.jpg)