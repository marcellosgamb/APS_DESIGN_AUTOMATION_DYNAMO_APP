## In Depth
ByCoordinates (x, y, z) will return a Vector from X, Y, and Z coordinates. The input coordinate location defines the Vector's position and length. In the example below, a Vector is returned from a coordinate location of (1,0,1) and is represented as a Line.
___
## Example File

![ByCoordinates (x, y, z)](./Autodesk.DesignScript.Geometry.Point.ByCoordinates(x,%20y,%20z)_img.jpg)

