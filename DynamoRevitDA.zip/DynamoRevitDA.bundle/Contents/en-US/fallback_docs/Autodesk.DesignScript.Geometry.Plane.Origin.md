## In Depth
Origin will return a Point at the Origin of the WorldCoordinateSystem. In the example below, a Circle by centerpoint and radius is created using a Point at the WCS Origin.
___
## Example File

![Origin](./Autodesk.DesignScript.Geometry.Plane.Origin_img.jpg)

