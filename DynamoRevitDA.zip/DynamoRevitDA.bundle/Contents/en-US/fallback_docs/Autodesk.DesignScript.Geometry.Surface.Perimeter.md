## In Depth
Perimeter will return the length of a Surface's perimeter as a double. In the example below, a complex NurbsSurface's perimeter returns a value of 36.432.
___
## Example File

![Perimeter](./Autodesk.DesignScript.Geometry.Surface.Perimeter_img.jpg)

