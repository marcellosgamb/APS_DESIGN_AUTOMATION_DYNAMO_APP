## In Depth
Applies a uniform scaling, translation and rotation transformation to the given PanelSurface.
___
## Example File

![SetTransform](./Autodesk.DesignScript.Geometry.PanelSurface.SetTransform_img.jpg)
