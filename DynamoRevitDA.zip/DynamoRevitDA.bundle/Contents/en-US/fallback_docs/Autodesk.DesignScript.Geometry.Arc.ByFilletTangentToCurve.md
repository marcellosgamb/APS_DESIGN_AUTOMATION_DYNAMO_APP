## In Depth
Arc ByFilletTangentToCurve draws the best fit arc that is tangent to three input curves. In this example, we are using two input lines as reference curves and a circle for the arc to be tangent to.
___
## Example File

![ByFilletTangentToCurve](./Autodesk.DesignScript.Geometry.Arc.ByFilletTangentToCurve_img.jpg)

