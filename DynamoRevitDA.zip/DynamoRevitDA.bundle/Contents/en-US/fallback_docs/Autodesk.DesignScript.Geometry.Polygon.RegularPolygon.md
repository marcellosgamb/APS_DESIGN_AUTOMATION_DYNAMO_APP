## In Depth
Polygon Regular Polygon is a simple component that will inscribe a regular polygon of any number of sides into a circle. In this example, we create the reference circle from a random Best Fit Through Points and draw a six-sided polygon inside the circle.
___
## Example File

![RegularPolygon](./Autodesk.DesignScript.Geometry.Polygon.RegularPolygon_img.jpg)

