## In Depth
Trim overlapping panels to surface boundary.
___
## Example File

![PanelSurfaceBoundaryCondition.Trim](./Autodesk.DesignScript.Geometry.PanelSurfaceBoundaryCondition.Trim_img.jpg)
