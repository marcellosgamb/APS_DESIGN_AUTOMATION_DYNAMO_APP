## In Depth
ByIndices (a, b, c) (a, b, c) will return an IndexGroup of three Indices. In the example below, three indices are defined for a three-sided Mesh created with Mesh.ByPointsFacesIndices.
___
## Example File

![ByIndices (a, b, c)](./Autodesk.DesignScript.Geometry.IndexGroup.ByIndices(a,%20b,%20c)_img.jpg)

