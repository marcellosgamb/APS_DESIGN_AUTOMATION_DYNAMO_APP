## In Depth
VertexCount will return the number of Vertices of a PolySurface as an integer. In the example below, an extruded hexagon returns a Vertice count of 12. The Vertices are represented as Points.
___
## Example File

![VertexCount](./Autodesk.DesignScript.Geometry.PolySurface.VertexCount_img.jpg)

