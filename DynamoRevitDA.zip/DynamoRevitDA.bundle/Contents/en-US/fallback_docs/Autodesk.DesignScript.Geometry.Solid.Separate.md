## In Depth
Solid.Separate will return the individual solids comprising a solid if they are not touching.
___
## Example File

![Solid.Separate](./Autodesk.DesignScript.Geometry.Solid.Separate_img.png)