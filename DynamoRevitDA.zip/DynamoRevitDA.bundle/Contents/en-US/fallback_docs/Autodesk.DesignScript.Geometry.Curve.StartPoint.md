## In Depth
Start Point will return the start point of an input curve. In the example below, we first create a Nurbs Curve using a ByControlPoints node, with a set of randomly generated points as the input. We can find the start point of this curve by using a StartPoint node.
___
## Example File

![StartPoint](./Autodesk.DesignScript.Geometry.Curve.StartPoint_img.jpg)

