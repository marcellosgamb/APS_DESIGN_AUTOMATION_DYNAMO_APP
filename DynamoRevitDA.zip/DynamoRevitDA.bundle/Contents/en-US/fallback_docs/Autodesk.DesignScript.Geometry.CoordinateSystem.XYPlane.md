## In Depth
XYPlane returns a plane in Dynamo from a reference point in the Revit conceptual design environment.
___
## Example File

![XYPlane](./Autodesk.DesignScript.Geometry.CoordinateSystem.XYPlane_img.jpg)

