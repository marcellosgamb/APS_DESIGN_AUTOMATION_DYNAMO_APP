## In Depth
`Circle.ByThreePoints` receives 3 point inputs and creates a circle that passes through each point.

In the example below, we use 3 randomly generated points on the Z-plane to create a circle.

___
## Example File

![ByThreePoints](./Autodesk.DesignScript.Geometry.Circle.ByThreePoints_img.jpg)

