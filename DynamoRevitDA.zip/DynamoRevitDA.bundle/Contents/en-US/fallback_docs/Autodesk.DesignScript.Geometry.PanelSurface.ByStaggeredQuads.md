## In Depth
Panels the input surface in a staggered square pattern. By default, the pattern is staggered horizontally.
___
## Example File

![ByStaggeredQuads](./Autodesk.DesignScript.Geometry.PanelSurface.ByStaggeredQuads_img.jpg)
