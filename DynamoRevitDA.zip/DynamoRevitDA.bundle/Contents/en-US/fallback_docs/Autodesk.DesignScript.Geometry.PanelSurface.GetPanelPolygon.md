## In Depth
Returns the polygonal boundary for each panel in the list of panel indices.
___
## Example File

![GetPanelPolygon](./Autodesk.DesignScript.Geometry.PanelSurface.GetPanelPolygon_img.jpg)
