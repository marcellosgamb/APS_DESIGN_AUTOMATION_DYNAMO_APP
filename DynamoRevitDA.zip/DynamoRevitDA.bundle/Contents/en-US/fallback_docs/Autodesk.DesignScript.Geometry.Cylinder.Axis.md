## In Depth
The Axis of the given cylinder.
___
## Example File

![Axis](./Autodesk.DesignScript.Geometry.Cylinder.Axis_img.jpg)

