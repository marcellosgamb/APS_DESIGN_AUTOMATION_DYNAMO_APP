## In Depth
Geometry Scale2D Scales a Geometry in two directions from a Base Plane and two reference Points. In the example file, a Cone is scaled from its End Point to its Centroid in relation to the YZ-Plane.
___
## Example File

![Scale2D](./Autodesk.DesignScript.Geometry.Geometry.Scale2D_img.jpg)

