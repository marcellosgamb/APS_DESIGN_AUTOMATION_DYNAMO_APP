## In-Depth
This node shows the number of sides or edges in each T-Spline Face. 
In the example below, `TSplineFace.Sides` is used to query the number of sides on all faces of a quadball primitive.

## Example File

![Example](./Autodesk.DesignScript.Geometry.TSpline.TSplineFace.Sides_img.jpg)