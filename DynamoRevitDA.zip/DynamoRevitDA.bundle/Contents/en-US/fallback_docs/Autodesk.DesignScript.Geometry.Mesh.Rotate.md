## In-Depth
`MeshRotate` node rotates any mesh around the input axis by input degrees, centered at the origin.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Rotate_img.jpg)