## In Depth
CurveGeometry will return an Edge as a Curve. In the example below, an identified Edge is represented as a Curve.
___
## Example File

![CurveGeometry](./Autodesk.DesignScript.Geometry.Edge.CurveGeometry_img.jpg)

