## In Depth
Panels the input surface in parallelograms tiled vertically and horizontally. Each parallelogram is a square with a shear applied along the V-axis or U-axis determined by the ‘alignWithUAxis’ input and a shear factor. By default the parallelograms are aligned with the V-axis.
___
## Example File

![ByParallelograms](./Autodesk.DesignScript.Geometry.PanelSurface.ByParallelograms_img.jpg)
