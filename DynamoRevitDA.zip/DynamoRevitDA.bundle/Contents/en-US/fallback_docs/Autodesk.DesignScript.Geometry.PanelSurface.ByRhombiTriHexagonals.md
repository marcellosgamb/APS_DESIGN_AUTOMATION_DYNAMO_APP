## In Depth
Panels the input surface in a tiling with one triangle, two squares, and one hexagon at each vertex.
___
## Example File

![ByRhombiTriHexagonals](./Autodesk.DesignScript.Geometry.PanelSurface.ByRhombiTriHexagonals_img.jpg)
