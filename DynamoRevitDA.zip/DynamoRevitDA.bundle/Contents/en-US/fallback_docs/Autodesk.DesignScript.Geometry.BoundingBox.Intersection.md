## In Depth
Bounding Box Intersection solves for the Intersection for two Bounding Boxes and returns the overlapping Bounding Box. This example uses two cones to demonstrate the use of this node. In order to visualize the Box we are converting it to a Cuboid.
___
## Example File

![Intersection](./Autodesk.DesignScript.Geometry.BoundingBox.Intersection_img.jpg)

