## In Depth
Nurbs Curve By Points inputs a list of points to draw a Nurbs Curve through. This example generates six random points on the World XY plane and connects them in order in the X and Y directions. 
___
## Example File

![ByPoints (points)](./Autodesk.DesignScript.Geometry.NurbsCurve.ByPoints(points)_img.jpg)

