<!--- Autodesk.DesignScript.Geometry.CoordinateSystem.Scale(xamount, yamount, zamount) --->
<!--- 5IXBOJ4T7DGQ4FYV7OJBRP77VS7URLKC6BUG7AUFBR6QSPUYOFIA --->
## In Depth
Scale the coordinate system non-uniformly around the origin.
___
## Example File

![Scale (xamount, yamount, zamount)](./5IXBOJ4T7DGQ4FYV7OJBRP77VS7URLKC6BUG7AUFBR6QSPUYOFIA_img.jpg)

