## In Depth
ZXPlane will return a plane on the Z and X axes of a CoordinateSystem. In the example below, a plane is placed on the ZX axes of a rotated CoordinateSystem.
___
## Example File

![ZXPlane](./Autodesk.DesignScript.Geometry.CoordinateSystem.ZXPlane_img.jpg)

