## In Depth
IsRational will return a boolean value based on whether a NurbsSurface is rational. In the example below, a NurbsSurface created by approximating a Surface returns a false value.
___
## Example File

![IsRational](./Autodesk.DesignScript.Geometry.NurbsCurve.IsRational_img.jpg)

