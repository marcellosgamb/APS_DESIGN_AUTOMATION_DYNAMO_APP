## In Depth
ByPointsRadius will return a Cylinder from a start Point, end Point, and radius value. In the example below, adjusting the number sliders will change the point positions as well as the Cylinder's radius.
___
## Example File

![ByPointsRadius](./Autodesk.DesignScript.Geometry.Cylinder.ByPointsRadius_img.jpg)

