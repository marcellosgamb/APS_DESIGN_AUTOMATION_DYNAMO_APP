## In Depth
Transforms geometry by the given CoordinateSystem's transform.
___
## Example File

![Transform (cs)](./Autodesk.DesignScript.Geometry.Geometry.Transform(geometry,%20cs)_img.jpg)

