## In Depth
Panels the input surface in a diamond-shaped pattern.
___
## Example File

![ByDiamonds](./Autodesk.DesignScript.Geometry.PanelSurface.ByDiamonds_img.jpg)
