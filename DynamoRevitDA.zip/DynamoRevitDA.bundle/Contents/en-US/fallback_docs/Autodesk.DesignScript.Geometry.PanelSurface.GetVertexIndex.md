## In Depth
Returns the index for a given panel on the input surface and for the vertex inside the panel.
___
## Example File

![GetVertexIndex](./Autodesk.DesignScript.Geometry.PanelSurface.GetVertexIndex_img.jpg)
