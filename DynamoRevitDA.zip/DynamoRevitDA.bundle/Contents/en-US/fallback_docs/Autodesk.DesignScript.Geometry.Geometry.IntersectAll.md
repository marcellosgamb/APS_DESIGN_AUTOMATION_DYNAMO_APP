## In Depth
Geometry IntersectAll finds the Intersection Geometry that any number of Geometry objects share. In this example, the Intersection of three Spheres returns a Polysurface, otherwise known as a Solid Intersection.
___
## Example File

![IntersectAll](./Autodesk.DesignScript.Geometry.Geometry.IntersectAll_img.jpg)

