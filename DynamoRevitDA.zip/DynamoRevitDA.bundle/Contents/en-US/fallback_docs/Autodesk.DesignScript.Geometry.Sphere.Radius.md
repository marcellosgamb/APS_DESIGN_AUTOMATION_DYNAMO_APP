## In Depth
Radius will return the center of an input sphere. In the example below, we use a ByBestFit node to create a sphere based on a set of random points. We then use a Radius node to determine the size of the best fit sphere.
___
## Example File

![Radius](./Autodesk.DesignScript.Geometry.Sphere.Radius_img.jpg)

