## In Depth
Geometry Mirror reflects a Geometry across a defined Plane. In this example, we are Mirroring a Cone across the Y-Axis.
___
## Example File

![Mirror](./Autodesk.DesignScript.Geometry.Geometry.Mirror_img.jpg)

