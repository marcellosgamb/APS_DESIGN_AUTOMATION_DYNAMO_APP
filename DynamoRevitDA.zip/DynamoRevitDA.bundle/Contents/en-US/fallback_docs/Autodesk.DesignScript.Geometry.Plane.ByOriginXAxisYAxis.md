## In Depth
Plane by Origin XAxis YAxis uses an origin point and two vectors to define a plane. The Normal vector of the plane is created by taking the cross product of the X and Y axis vectors. In the example below, we use world YAxis as the xAxis, and use two code blocks to define the origin point and input xAxis. 
___
## Example File

![ByOriginXAxisYAxis](./Autodesk.DesignScript.Geometry.Plane.ByOriginXAxisYAxis_img.jpg)

