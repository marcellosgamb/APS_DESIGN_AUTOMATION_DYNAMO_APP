## In Depth
Returns a BSplineCurve through the points, with tangent directions.
___
## Example File

![ByPointsTangents](./Autodesk.DesignScript.Geometry.NurbsCurve.ByPointsTangents_img.jpg)

