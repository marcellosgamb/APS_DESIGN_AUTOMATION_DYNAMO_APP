## In Depth
Geometry DistanceTo returns the distance between two geometries. This example finds the distance between two Spheres.
___
## Example File

![DistanceTo](./Autodesk.DesignScript.Geometry.Geometry.DistanceTo_img.jpg)

