## In Depth
ToPolySurface will return a bounding box as a PolySurface. In the example below, the bounding box of several unioned spheres is returned as a PolySurface. The resulting PolySurface is displayed with a color and transparency to show the original geometry inside.
___
## Example File

![ToPolySurface](./Autodesk.DesignScript.Geometry.BoundingBox.ToPolySurface_img.jpg)

