## In Depth
Angle will find the total angular length of a helix in degrees, where one complete turn is equal to 360. In the example below, we create a helix using Helix By Axis, then use Angle to find the total angle of the helix.
___
## Example File

![Angle](./Autodesk.DesignScript.Geometry.Helix.Angle_img.jpg)

