## In Depth
Returns true if the Surface is periodic in the U direction.
___
## Example File

![IsPeriodicInU](./Autodesk.DesignScript.Geometry.NurbsSurface.IsPeriodicInU_img.jpg)

