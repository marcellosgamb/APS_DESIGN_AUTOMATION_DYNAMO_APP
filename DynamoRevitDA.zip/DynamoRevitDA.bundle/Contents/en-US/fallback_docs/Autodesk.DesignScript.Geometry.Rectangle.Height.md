## In Depth
Text note height is returned as a double. The height value is relative to the view scale.
___
## Example File

![Height](./Autodesk.DesignScript.Geometry.Rectangle.Height_img.jpg)

