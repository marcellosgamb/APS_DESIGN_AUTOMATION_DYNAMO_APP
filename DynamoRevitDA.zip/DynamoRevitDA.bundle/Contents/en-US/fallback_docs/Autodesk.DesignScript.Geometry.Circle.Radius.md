## In Depth
`Circle.Radius` finds the radius of a given circle.

In the example below, we create a circle using `Circle.ByBestFitThroughPoints` and then extract the radius of the circle.

___
## Example File

![Radius](./Autodesk.DesignScript.Geometry.Circle.Radius_img.jpg)

