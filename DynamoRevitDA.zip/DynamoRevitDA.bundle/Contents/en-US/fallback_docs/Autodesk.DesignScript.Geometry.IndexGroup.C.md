## In Depth
C will return the value of Index C. In the example below, the Index value of C is returned as 2 in a three-sided Mesh.
___
## Example File

![C](./Autodesk.DesignScript.Geometry.IndexGroup.C_img.jpg)

