## In Depth
Returns the number of vertices in the PanelSurface.
___
## Example File

![NumVertices](./Autodesk.DesignScript.Geometry.PanelSurface.NumVertices_img.jpg)
