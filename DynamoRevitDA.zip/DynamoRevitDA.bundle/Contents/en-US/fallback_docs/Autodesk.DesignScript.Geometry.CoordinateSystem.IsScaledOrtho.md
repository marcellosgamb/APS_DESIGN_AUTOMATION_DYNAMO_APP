## In Depth
Tests if the scaling orthogonal, i.e. does it have a shear component.
___
## Example File

![IsScaledOrtho](./Autodesk.DesignScript.Geometry.CoordinateSystem.IsScaledOrtho_img.jpg)

