## In Depth
EndVertex will return the Vertex at the end of an Edge. In the example below, an end Vertex is represented as a Point.
___
## Example File

![EndVertex](./Autodesk.DesignScript.Geometry.Edge.EndVertex_img.jpg)

