## In Depth
Obtain the Determinant of this CoordinateSystem.
___
## Example File

![Determinant](./Autodesk.DesignScript.Geometry.CoordinateSystem.Determinant_img.jpg)

