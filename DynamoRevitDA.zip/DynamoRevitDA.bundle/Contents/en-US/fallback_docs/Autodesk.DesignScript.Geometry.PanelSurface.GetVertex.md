## In Depth
Returns the vertex corresponding to the vertex index in the PanelSurface.
___
## Example File

![GetVertex](./Autodesk.DesignScript.Geometry.PanelSurface.GetVertex_img.jpg)
