## In Depth
Line by Start Point Direction Length creates a line beginning at the startPoint input, and with a length and direction according to the input direction vector and length. In the example below, we use a code block specify the x,y, and z coordinates of a point. We then use a number slider to control the length of the line.
___
## Example File

![ByStartPointDirectionLength](./Autodesk.DesignScript.Geometry.Line.ByStartPointDirectionLength_img.jpg)

