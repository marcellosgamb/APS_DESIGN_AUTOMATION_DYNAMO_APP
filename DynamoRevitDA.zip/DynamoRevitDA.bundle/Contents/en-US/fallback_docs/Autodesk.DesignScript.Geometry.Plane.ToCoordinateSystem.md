## In Depth
Plane To Coordinate System will return a Coordinate System based on the input plane, using the plane's origin, XAxis and YAxis. In the example below we first use a set of random points to create a Plane by Best Fit Through Points. We can then use ToCoordinateSystem to convert the Plane to a Coordinate System 
___
## Example File

![ToCoordinateSystem](./Autodesk.DesignScript.Geometry.Plane.ToCoordinateSystem_img.jpg)

