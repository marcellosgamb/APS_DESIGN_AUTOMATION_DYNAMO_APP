## In Depth
`Arc.ByThreePoints` draws an arc from three points, given the start point, end point, and a point between them. 

In the example below, we draw an arc from three randomly created points.

___
## Example File

![ByThreePoints](./Autodesk.DesignScript.Geometry.Arc.ByThreePoints_img.jpg)

