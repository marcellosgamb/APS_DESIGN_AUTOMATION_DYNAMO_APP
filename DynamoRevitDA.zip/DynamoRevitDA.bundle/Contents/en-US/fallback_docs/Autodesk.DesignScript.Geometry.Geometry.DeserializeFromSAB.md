## In Depth
DeserializeFromSAB will return geometry from SAB format data. In the example below, SAB data is read from a file and deserialized into a skewed cylinder.
___
## Example File

![DeserializeFromSAB](./Autodesk.DesignScript.Geometry.Geometry.DeserializeFromSAB_img.jpg)

