## In Depth
Returns the point corresponding to the vertex index in the PanelSurface.
___
## Example File

![GetPoint](./Autodesk.DesignScript.Geometry.PanelSurface.GetPoint_img.jpg)
