## In Depth
Returns a new Curve approximated with the supplied tolerance.
___
## Example File

![Simplify](./Autodesk.DesignScript.Geometry.Curve.Simplify_img.jpg)

