## In Depth
Plane XY creates a plane in the world XY directions. The normal of this plane is the world Z-Axis. In the example file, we show Plane XY, Plane YZ, and Plane XZ. In the image, the XY plane is highlighted.
___
## Example File

![XY](./Autodesk.DesignScript.Geometry.Plane.XY_img.jpg)

