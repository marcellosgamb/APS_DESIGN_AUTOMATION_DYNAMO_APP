## In Depth
Join this curve and the input curve into a new PolyCurve, maintaining the original curves exactly.
___
## Example File

![Join](./Autodesk.DesignScript.Geometry.Curve.Join_img.jpg)

