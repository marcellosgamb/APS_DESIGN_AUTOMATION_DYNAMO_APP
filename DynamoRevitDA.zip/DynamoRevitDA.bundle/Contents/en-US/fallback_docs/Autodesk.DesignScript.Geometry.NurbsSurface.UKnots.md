## In Depth
UKnots will return the Surface Knots in the U direction of a NurbsSurface. In the example below, the UKnots of the NurbsSurface are returned as a list of doubles.
___
## Example File

![UKnots](./Autodesk.DesignScript.Geometry.NurbsSurface.UKnots_img.jpg)

