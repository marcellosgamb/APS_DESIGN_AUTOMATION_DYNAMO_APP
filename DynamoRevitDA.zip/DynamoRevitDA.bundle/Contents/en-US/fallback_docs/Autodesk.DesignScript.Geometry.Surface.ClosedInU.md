## In Depth
ClosedInU will return a boolean value based on whether a Surface is closed in it's U direction. In the example below, an extruded circle that is closed in one direction returns false for being closed in U.
___
## Example File

![ClosedInU](./Autodesk.DesignScript.Geometry.Surface.ClosedInU_img.jpg)

