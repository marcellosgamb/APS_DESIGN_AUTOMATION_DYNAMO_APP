## In Depth
NumControlPointsU will count the control points in the U direction of a NurbsSurface and return an integer. In the example below, the NurbsSurface returns an integer of 22 for its U control points. The control points are returned as Points using NurbsSurface.ControlPoints.
___
## Example File

![NumControlPointsU](./Autodesk.DesignScript.Geometry.NurbsSurface.NumControlPointsU_img.jpg)

