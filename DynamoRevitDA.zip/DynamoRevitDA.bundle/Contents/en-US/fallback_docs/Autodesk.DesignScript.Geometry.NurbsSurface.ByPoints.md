## In Depth
Revit will generate and contour a mesh from a list of supplied points. The points cannot be collinear.
___
## Example File

![ByPoints](./Autodesk.DesignScript.Geometry.NurbsSurface.ByPoints_img.jpg)

