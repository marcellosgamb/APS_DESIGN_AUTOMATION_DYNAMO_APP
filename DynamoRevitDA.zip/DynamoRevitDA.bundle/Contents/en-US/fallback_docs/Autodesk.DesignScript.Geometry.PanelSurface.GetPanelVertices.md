## In Depth
Returns the vertices for each panel in the list of panel indices.
___
## Example File

![GetPanelVertices](./Autodesk.DesignScript.Geometry.PanelSurface.GetPanelVertices_img.jpg)
