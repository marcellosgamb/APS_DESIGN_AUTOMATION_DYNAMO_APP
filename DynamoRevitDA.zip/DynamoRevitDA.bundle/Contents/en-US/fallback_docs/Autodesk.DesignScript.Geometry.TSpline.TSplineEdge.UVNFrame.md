## In-Depth
In the example below, `TSplineEdge.UVNFrame` and `TSplineUVNFrame.Position` nodes are used to preview the position of border edges of a T-Spline surface.


## Example File

![Example](./Autodesk.DesignScript.Geometry.TSpline.TSplineEdge.UVNFrame_img.jpg)