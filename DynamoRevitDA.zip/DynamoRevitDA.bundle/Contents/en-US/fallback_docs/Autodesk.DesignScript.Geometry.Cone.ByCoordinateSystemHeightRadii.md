## In Depth
Cone ByCoordinateSystemHeightRadii creates a truncated Cone geometry from two Radii, the starting Origin, and a Height value. This example shows a dynamic Cone around the World Origin, constructed with three Number Sliders.
___
## Example File

![ByCoordinateSystemHeightRadii](./Autodesk.DesignScript.Geometry.Cone.ByCoordinateSystemHeightRadii_img.jpg)

