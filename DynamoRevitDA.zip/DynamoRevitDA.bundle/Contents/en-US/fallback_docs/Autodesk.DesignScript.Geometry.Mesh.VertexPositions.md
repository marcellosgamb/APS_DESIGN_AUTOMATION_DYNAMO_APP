## In Depth
VertexPositions will return a Mesh face's Vertex positions as Points. In the example below, the Vertex positions of a four-sided Mesh face are returned as Points.
___
## Example File

![VertexPositions](./Autodesk.DesignScript.Geometry.Mesh.VertexPositions_img.jpg)

