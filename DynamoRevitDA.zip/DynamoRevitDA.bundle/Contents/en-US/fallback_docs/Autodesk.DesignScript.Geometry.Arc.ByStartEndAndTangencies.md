## In Depth
The Arc ByStartEndAndTangencies Action creates a compound arc using two Input Points and their corresponding Vectors. In this example, two points are connected by a compound arc that is always tangent to the Y-Axis at its Start and End Points.
___
## Example File

![ByStartEndAndTangencies](./Autodesk.DesignScript.Geometry.Arc.ByStartEndAndTangencies_img.jpg)

