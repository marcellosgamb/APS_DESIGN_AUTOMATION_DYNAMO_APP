## In Depth
Bounding Box Intersects tests two bounding boxes for overlap. If the boxes intersect, the node will return True, otherwise it will return False. This example tests for an intersection between the Bounding Boxes of two input Cones.
___
## Example File

![Intersects](./Autodesk.DesignScript.Geometry.BoundingBox.Intersects_img.jpg)

