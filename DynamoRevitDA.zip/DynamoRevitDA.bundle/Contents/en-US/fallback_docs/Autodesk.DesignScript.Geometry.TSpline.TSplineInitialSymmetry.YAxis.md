## In-Depth
In the example below, `TSplineInitialSymmetry.YAxis` node confirms if the axial symmetry is applied around the Y axis. 

## Example File

![Example](./Autodesk.DesignScript.Geometry.TSpline.TSplineInitialSymmetry.YAxis_img.jpg)
