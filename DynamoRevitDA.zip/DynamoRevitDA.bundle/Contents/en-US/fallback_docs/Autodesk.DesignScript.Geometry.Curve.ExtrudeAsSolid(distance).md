## In Depth
Extrudes a Curve in the Normal direction by the specified distance. Curve must be closed.
___
## Example File

![ExtrudeAsSolid (distance)](./Autodesk.DesignScript.Geometry.Curve.ExtrudeAsSolid(distance)_img.jpg)

