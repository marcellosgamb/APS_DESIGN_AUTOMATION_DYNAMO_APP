<!--- Autodesk.DesignScript.Geometry.Geometry.Translate(direction) --->
<!--- 4HVWIMWUUU4ZQWQXKFRWMQ5JABJVFMYBXFJZTHB2CQKCRQQ2FDVQ --->
## In Depth
Translate geometry in the given direction by the vector length.
___
## Example File

![Translate (direction)](./4HVWIMWUUU4ZQWQXKFRWMQ5JABJVFMYBXFJZTHB2CQKCRQQ2FDVQ_img.jpg)

