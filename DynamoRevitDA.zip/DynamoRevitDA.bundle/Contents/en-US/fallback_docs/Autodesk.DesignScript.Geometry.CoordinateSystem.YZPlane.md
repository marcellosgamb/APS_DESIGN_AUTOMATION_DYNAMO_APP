## In Depth
YZPlane returns a plane in Dynamo from a reference point in the Revit conceptual design environment.
___
## Example File

![YZPlane](./Autodesk.DesignScript.Geometry.CoordinateSystem.YZPlane_img.jpg)

