## In Depth
Allow panels to overlap the boundary.
___
## Example File

![PanelSurfaceBoundaryCondition.Keep](./Autodesk.DesignScript.Geometry.PanelSurfaceBoundaryCondition.Keep_img.jpg)
