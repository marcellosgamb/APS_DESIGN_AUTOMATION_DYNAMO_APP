## In Depth
ByOrigin (x, y) will return a new CoordinateSystem with the X and Y values of its origin as inputs. In the example below, a new CoordinateSystem is created with it's origin at (4,2,0) from inputs 4 and 2 into X and Y respectively.
___
## Example File

![ByOrigin (x, y)](./Autodesk.DesignScript.Geometry.CoordinateSystem.ByOrigin(x,%20y)_img.jpg)

