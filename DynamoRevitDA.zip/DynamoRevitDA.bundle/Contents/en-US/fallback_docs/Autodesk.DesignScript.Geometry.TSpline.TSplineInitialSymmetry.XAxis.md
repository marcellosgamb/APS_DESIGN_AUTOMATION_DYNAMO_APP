## In-Depth
In the example below, `TSplineInitialSymmetry.XAxis` node confirms if the axial symmetry is applied around the X axis. 

## Example File

![Example](./Autodesk.DesignScript.Geometry.TSpline.TSplineInitialSymmetry.XAxis_img.jpg)