## In Depth
Circle By Plane Radius is a condensed node to create any type of circle. In this example, we use the YZ plane to determine the circle direction, and a Number slider to dynamically control the circle’s radius.
___
## Example File

![ByPlaneRadius](./Autodesk.DesignScript.Geometry.Circle.ByPlaneRadius_img.jpg)

