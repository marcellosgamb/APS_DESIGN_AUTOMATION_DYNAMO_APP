## In Depth
`PolySurface.ByLoft (crossSections)` returns a new PolySurface by lofting between curves in a list. 

In the example below, a PolySurface is returned from lofting between two circles.

___
## Example File

![ByLoft (crossSections)](./Autodesk.DesignScript.Geometry.PolySurface.ByLoft(crossSections)_img.jpg)

