## In-Depth
`Mesh.Translate(x, y, z)` translates any given mesh by the given displacements in the X, Y, and Z directions defined in WCS respectively.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Translate(mesh,%20x,%20y,%20z)_img.jpg)