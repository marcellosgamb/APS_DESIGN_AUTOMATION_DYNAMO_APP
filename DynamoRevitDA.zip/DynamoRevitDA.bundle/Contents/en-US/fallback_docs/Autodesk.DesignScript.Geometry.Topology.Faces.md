## In Depth
Faces will return all the faces of a Revit element as surfaces in Dynamo.
___
## Example File

![Faces](./Autodesk.DesignScript.Geometry.Topology.Faces_img.jpg)

