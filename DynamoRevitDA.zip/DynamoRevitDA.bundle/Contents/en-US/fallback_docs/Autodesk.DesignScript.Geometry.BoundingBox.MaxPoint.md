## In Depth
Bounding Box MaxPoint returns the point that has the largest X, Y and Z values. This example shows a Bounding Box MaxPoint of a Sphere.
___
## Example File

![MaxPoint](./Autodesk.DesignScript.Geometry.BoundingBox.MaxPoint_img.jpg)

