## In Depth
Plane XZ creates a plane in the world XZ directions. The normal of this plane is the world Y-Axis. In the example file, we show Plane XY, Plane YZ, and Plane XZ. In the image, the XZ plane is highlighted.
___
## Example File

![XZ](./Autodesk.DesignScript.Geometry.Plane.XZ_img.jpg)

