## In-Depth
In the example below, `TSplineInitialSymmetry.ZAxis` node confirms if the axial symmetry is applied around the Z axis. 

## Example File

![Example](./Autodesk.DesignScript.Geometry.TSpline.TSplineInitialSymmetry.ZAxis_img.jpg)