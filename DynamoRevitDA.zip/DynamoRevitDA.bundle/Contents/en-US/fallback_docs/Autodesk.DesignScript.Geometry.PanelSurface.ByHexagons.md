## In Depth
Panels the input surface in a hexagonal tiling pattern.
___
## Example File

![ByHexagons](./Autodesk.DesignScript.Geometry.PanelSurface.ByHexagons_img.jpg)
