## In Depth
Point At Parameter will return the point on a surface specified by U and V parameters. In the example below, we first create a surface by using a BySweep2Rails node. We then use two number sliders to control the U and V values of the parameter for a PointAtParameter node.
___
## Example File

![PointAtParameter](./Autodesk.DesignScript.Geometry.Surface.PointAtParameter_img.jpg)

