## In Depth
FaceIndices will return the IndexGroup of a mesh face in counterclockwise order. In the example below, the an Indexgroup is returned for a four-sided mesh face.
___
## Example File

![FaceIndices](./Autodesk.DesignScript.Geometry.Mesh.FaceIndices_img.jpg)

