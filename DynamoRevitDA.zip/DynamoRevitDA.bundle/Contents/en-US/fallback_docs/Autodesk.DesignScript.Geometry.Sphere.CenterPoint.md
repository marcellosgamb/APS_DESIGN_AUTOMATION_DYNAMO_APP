## In Depth
Center Point will return the center of an input sphere. In the example below, we use a ByBestFit node to create a sphere based on a set of random points. We then use a CenterPoint node to determine the center of the best fit sphere.
___
## Example File

![CenterPoint](./Autodesk.DesignScript.Geometry.Sphere.CenterPoint_img.jpg)

