## In Depth
Tests if the scaling orthogonal and are all the vectors normalized.
___
## Example File

![IsUniscaledOrtho](./Autodesk.DesignScript.Geometry.CoordinateSystem.IsUniscaledOrtho_img.jpg)

