## In Depth
Returns the number of panels in the PanelSurface.
___
## Example File

![NumPanels](./Autodesk.DesignScript.Geometry.PanelSurface.NumPanels_img.jpg)
