## In Depth
Panels the input surface in a square grid, with each square split into two triangles by a diagonal. By default, the diagonal is from the bottom left corner to the top right corner.
___
## Example File

![ByDiagonallySplitSquares](./Autodesk.DesignScript.Geometry.PanelSurface.ByDiagonallySplitSquares_img.jpg)
