## In Depth
Width returns the horizontal dimension of a rectangular curtain panel as a double.
___
## Example File

![Width](./Autodesk.DesignScript.Geometry.Rectangle.Width_img.jpg)

