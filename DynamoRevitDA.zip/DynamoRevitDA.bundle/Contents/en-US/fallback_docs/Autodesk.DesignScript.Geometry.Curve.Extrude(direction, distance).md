## In Depth
Extrudes a Curve in the specified direction, by the specified distance.
___
## Example File

![Extrude (direction, distance)](./Autodesk.DesignScript.Geometry.Curve.Extrude(direction,%20distance)_img.jpg)

