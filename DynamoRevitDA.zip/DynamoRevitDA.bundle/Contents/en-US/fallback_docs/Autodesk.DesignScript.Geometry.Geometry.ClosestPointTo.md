## In Depth
Geometry ClosestPointTo finds the closest point from one geometry to another, adding a 3D Point to the document. This example finds the closest point on one Sphere to another.
___
## Example File

![ClosestPointTo](./Autodesk.DesignScript.Geometry.Geometry.ClosestPointTo_img.jpg)

