## In Depth
Subtract From will create a new surface by subtracting the input trimming geometry from they input surface. In the example below, we first create a surface by using a BySweep2Rails. We then use a series of number slider to contrel the length, width, and height of a cuboid. By using a SubtractFrom node, we can trim the surface by subracting out the area that intersects with the cuboid.
___
## Example File

![SubtractFrom](./Autodesk.DesignScript.Geometry.Surface.SubtractFrom_img.jpg)

