## In Depth
Surface by Sweep will create a surface by sweeping an input curve along a specfied path. In the example below, we use a sine curve in the y-direction as the profile curve. We rotate this curve by -90 degrees around the world z-axis to use as a path curve. Surface BySweep moves the profile curve along the path curve creating a surface.
___
## Example File

![BySweep](./Autodesk.DesignScript.Geometry.Solid.BySweep_img.jpg)

