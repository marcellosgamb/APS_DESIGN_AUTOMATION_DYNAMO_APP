## In Depth
ByOrigin (origin) will return a new CoordinateSystem with it's origin at the input Point. In the example below, a new CoordinateSystem is created with its origin at (4,4,0).
___
## Example File

![ByOrigin (origin)](./Autodesk.DesignScript.Geometry.CoordinateSystem.ByOrigin(origin)_img.jpg)

