## In-Depth
`Mesh.Translate` (vector) node translates any mesh type in the direction and magnitude of the input Vector.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Translate(mesh,%20vector)_img.jpg)