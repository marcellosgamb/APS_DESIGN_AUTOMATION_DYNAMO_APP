## In Depth
SurfaceGeometry will return a Face as a Surface. In the example below, a Face is identified on the Solid and returned as a Surface.
___
## Example File

![SurfaceGeometry](./Autodesk.DesignScript.Geometry.Face.SurfaceGeometry_img.jpg)

