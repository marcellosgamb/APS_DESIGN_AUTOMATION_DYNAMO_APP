<!--- Autodesk.DesignScript.Geometry.Surface.Thicken(thickness, both_sides) --->
<!--- 4FFK6PGYCVKERZWXQC6TEBOQTHVXXN3QLAX5MTLXGZEAB4KH4WEQ --->
## In Depth
Thicken Surface into a Solid, extruding in the direction of Surface normals. If both_sides parameter is true, surface is thickened on both sides.
___
## Example File

![Thicken (thickness, both_sides)](./4FFK6PGYCVKERZWXQC6TEBOQTHVXXN3QLAX5MTLXGZEAB4KH4WEQ_img.jpg)

