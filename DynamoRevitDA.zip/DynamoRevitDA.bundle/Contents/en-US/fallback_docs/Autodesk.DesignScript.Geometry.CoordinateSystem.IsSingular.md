## In Depth
Determine whether it is possible to get the Inverse of this CoordinateSystem.
___
## Example File

![IsSingular](./Autodesk.DesignScript.Geometry.CoordinateSystem.IsSingular_img.jpg)

