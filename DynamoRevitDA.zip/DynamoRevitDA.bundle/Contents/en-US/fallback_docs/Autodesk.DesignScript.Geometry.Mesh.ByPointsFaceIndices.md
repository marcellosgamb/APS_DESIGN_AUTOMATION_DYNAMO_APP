## In Depth
ByPointsFaceIndices will return a Mesh based on input vertices as Points and input indices. In the example below, a four-sided Mesh is created with four Points and an IndexGroup of four indices.
___
## Example File

![ByPointsFaceIndices](./Autodesk.DesignScript.Geometry.Mesh.ByPointsFaceIndices_img.jpg)

