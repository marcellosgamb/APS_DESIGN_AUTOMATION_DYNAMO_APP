## In Depth
Geometry Intersect finds the Intersection Geometry that two Geometry objects share. In this example, the Intersection of two Spheres returns a Polysurface, otherwise known as a Solid Intersection.
___
## Example File

![Intersect](./Autodesk.DesignScript.Geometry.Geometry.Intersect_img.jpg)

