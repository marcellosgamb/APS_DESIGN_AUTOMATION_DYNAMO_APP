<!--- Autodesk.DesignScript.Geometry.CoordinateSystem.Transform(coordinateSystem, fromCoordinateSystem, contextCoordinateSystem) --->
<!--- 43XHCR2GSF5A34R3G2P7OGOWDWYKS3WCXART33FSES5M5ZF2MHJA --->
## In Depth
CoordinateSystem.Transform will transform the given Coordinate System from a source Coordinate System to a new Coordinate System.
___
## Example File

![CoordinateSystem.Transform](./43XHCR2GSF5A34R3G2P7OGOWDWYKS3WCXART33FSES5M5ZF2MHJA_img.jpg)