## In Depth
B will return the value of Index B. In the example below, the Index value of B is returned as 1 in a three-sided Mesh.
___
## Example File

![B](./Autodesk.DesignScript.Geometry.IndexGroup.B_img.jpg)

