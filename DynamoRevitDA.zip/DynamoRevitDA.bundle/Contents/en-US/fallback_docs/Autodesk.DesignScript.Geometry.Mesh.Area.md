## In-Depth
`Mesh.Area` returns the area of the input mesh. In the example below, we are creating a cone using the `Mesh.Cone` node. Then the `Mesh.Area` node is used to calculate the area of the mesh of the cone.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Area_img.jpg)