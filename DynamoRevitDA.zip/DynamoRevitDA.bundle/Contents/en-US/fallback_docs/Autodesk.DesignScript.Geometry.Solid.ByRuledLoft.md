## In Depth
Create a Solid by lofting between input cross-sections comprising of closed PolyCurves.
___
## Example File

![Solid.ByRuledLoft](./Autodesk.DesignScript.Geometry.Solid.ByRuledLoft_img.png)