## In Depth
Panels the input surface in a square tiling pattern.
___
## Example File

![ByQuads](./Autodesk.DesignScript.Geometry.PanelSurface.ByQuads_img.jpg)
