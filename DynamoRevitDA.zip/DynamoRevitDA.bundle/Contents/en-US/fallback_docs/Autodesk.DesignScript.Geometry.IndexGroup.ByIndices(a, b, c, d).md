## In Depth
ByIndices (a, b, c, d) (a, b, c, d) (a, b, c, d) will return an IndexGroup of four Indices. In the example below, four indices are defined for a four-sided Mesh created with Mesh.ByPointsFacesIndices.
___
## Example File

![ByIndices (a, b, c, d)](./Autodesk.DesignScript.Geometry.IndexGroup.ByIndices(a,%20b,%20c,%20d)_img.jpg)

