## In-Depth
`Mesh.Scale` (scaleFactor) node scales the mesh by the input amount uniformly around the origin.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Scale(mesh,%20scaleFactor)_img.jpg)