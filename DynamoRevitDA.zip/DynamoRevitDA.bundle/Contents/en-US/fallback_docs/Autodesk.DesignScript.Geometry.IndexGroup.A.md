## In Depth
A will return the value of Index A. In the example below, the Index value of A is returned as 0 in a three-sided Mesh.
___
## Example File

![A](./Autodesk.DesignScript.Geometry.IndexGroup.A_img.jpg)

