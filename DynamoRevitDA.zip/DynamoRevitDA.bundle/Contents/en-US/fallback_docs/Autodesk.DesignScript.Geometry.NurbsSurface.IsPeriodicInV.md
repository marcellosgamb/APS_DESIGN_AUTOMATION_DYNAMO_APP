## In Depth
Returns true if the Surface is periodic in the V direction.
___
## Example File

![IsPeriodicInV](./Autodesk.DesignScript.Geometry.NurbsSurface.IsPeriodicInV_img.jpg)

