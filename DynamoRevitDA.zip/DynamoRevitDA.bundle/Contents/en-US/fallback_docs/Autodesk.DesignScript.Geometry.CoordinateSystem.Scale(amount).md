## In Depth
Scale the coordinate system uniformly around the origin.
___
## Example File

![Scale (amount)](./Autodesk.DesignScript.Geometry.CoordinateSystem.Scale(amount)_img.jpg)

