## In Depth
In the example below, a set of border edges of a T-Spline surface is selected and used as input for the `TSplineSurface.ExtrudeEdges` node. The result is translated to the side for better preview. 
___
## Example File

![TSplineSurface.ExtrudeEdges](./5MRWZW5S4JJMDCAQNQWK32MPFTU5RFV6GLUOOMEN6FLMBO2FOFGQ_img.jpg)