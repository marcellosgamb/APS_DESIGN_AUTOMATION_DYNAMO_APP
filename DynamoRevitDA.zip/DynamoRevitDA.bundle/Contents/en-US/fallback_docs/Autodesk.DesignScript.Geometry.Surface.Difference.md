## In Depth
Surface.Difference removes the given surfaces from the input surface.
___
## Example File

![Surface.Difference](./Autodesk.DesignScript.Geometry.Surface.Difference_img.png)