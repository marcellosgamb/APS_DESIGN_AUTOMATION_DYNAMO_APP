## In Depth
Extrudes a Curve in the specified direction, by the length of the input Vector. Curve must be closed.
___
## Example File

![ExtrudeAsSolid (direction)](./Autodesk.DesignScript.Geometry.Curve.ExtrudeAsSolid(direction)_img.jpg)

