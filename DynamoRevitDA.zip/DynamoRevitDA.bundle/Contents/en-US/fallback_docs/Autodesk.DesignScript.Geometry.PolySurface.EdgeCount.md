## In Depth
EdgeCount will return the number of Edges on a PolySurface. In the example below, an extruded hexagon has an Edge count of 18. The edges are represented as Lines.
___
## Example File

![EdgeCount](./Autodesk.DesignScript.Geometry.PolySurface.EdgeCount_img.jpg)

