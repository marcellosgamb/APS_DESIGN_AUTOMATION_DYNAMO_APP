## In Depth
IsEmpty will return a boolean value based on whether the Bounding Box is empty or not.
___
## Example File

![IsEmpty](./Autodesk.DesignScript.Geometry.BoundingBox.IsEmpty_img.jpg)

