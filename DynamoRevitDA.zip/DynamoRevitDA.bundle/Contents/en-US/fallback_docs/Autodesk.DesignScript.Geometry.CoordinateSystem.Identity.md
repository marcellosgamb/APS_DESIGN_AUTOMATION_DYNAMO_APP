## In Depth
Identity will return what is passed in. In the example below, the Identity node is used to preview each piece of geometry created inside a Code Block.
___
## Example File

![Identity](./Autodesk.DesignScript.Geometry.CoordinateSystem.Identity_img.jpg)

