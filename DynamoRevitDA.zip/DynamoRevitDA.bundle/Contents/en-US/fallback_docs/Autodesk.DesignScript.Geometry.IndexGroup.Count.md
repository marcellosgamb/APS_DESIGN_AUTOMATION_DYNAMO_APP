## In Depth
Count will return an integer that represents the number of Indices in an IndexGroup. In the example below, Index counts are returned for Mesh faces with three and four edges.
___
## Example File

![Count](./Autodesk.DesignScript.Geometry.IndexGroup.Count_img.jpg)

