## In Depth
Panels the input surface in a square grid, with each square split into four triangles by its diagonals.
___
## Example File

![ByCrossSplitSquares](./Autodesk.DesignScript.Geometry.PanelSurface.ByCrossSplitSquares_img.jpg)
