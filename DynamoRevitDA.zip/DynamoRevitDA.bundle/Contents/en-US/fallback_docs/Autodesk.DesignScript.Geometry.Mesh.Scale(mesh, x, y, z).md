## In-Depth
`Mesh.Scale` ( x, y, z ) scales mesh non-uniformly in any given direction by scale factor around origin.

## Example File

![Example](./Autodesk.DesignScript.Geometry.Mesh.Scale(mesh,%20x,%20y,%20z)_img.jpg)