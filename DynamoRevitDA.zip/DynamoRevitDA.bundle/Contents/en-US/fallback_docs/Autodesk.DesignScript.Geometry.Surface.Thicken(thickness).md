## In Depth
Thicken Surface into a Solid, extruding in the direction of Surface normals on both sides of the Surface.
___
## Example File

![Thicken (thickness)](./Autodesk.DesignScript.Geometry.Surface.Thicken(thickness)_img.jpg)

