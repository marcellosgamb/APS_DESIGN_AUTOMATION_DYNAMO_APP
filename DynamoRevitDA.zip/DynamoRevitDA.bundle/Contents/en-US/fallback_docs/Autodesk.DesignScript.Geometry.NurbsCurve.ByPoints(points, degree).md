## In Depth
Nurbs Curve By Points inputs a list of points to draw a Nurbs Curve through, and also allows us to change the degree of the curve. This example generates six random points on the World XY plane and connects them in order in the X and Y directions. 
___
## Example File

![ByPoints (points, degree)](./Autodesk.DesignScript.Geometry.NurbsCurve.ByPoints(points,%20degree)_img.jpg)

