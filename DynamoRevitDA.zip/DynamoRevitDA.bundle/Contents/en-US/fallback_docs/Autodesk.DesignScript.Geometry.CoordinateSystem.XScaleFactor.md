## In Depth
XScaleFactor will return a double representing the scale factor along the X Axis. In the example below, a cylinder is scaled by 2.3, returning an X scale factor of 2.3.
___
## Example File

![XScaleFactor](./Autodesk.DesignScript.Geometry.CoordinateSystem.XScaleFactor_img.jpg)

